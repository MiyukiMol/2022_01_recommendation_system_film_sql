SELECT * FROM movie_5.actor;
USE movie_5;
-- create id
-- ALTER TABLE actor ADD id_actor int NOT NULL AUTO_INCREMENT primary key;
-- ALTER TABLE actor CHANGE id_actor id_actor INT(20) NOT NULL FIRST;
-- ALTER TABLE actor DROP COLUMN MyUnknownColumn;

ALTER TABLE movie_1
ADD CONSTRAINT fk_actor_1
FOREIGN KEY (id_actor_1) REFERENCES actor(id_actor); 
ALTER TABLE movie_1
ADD CONSTRAINT fk_actor_2
FOREIGN KEY (id_actor_2) REFERENCES actor(id_actor); 
ALTER TABLE movie_1
ADD CONSTRAINT fk_actor_3
FOREIGN KEY (id_actor_3) REFERENCES actor(id_actor); 