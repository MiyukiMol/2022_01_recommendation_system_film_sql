SELECT * FROM movie_5.asso_movie_genres;

ALTER TABLE `movie_5`.`asso_movie_genres` 
CHANGE COLUMN `id_genres` `id_genres` INT NOT NULL ,
ADD PRIMARY KEY (`id_movie`, `id_genres`);
;

ALTER TABLE asso_movie_genres
ADD CONSTRAINT fk_genre
FOREIGN KEY (id_genres) REFERENCES genres(id_genres); 

ALTER TABLE asso_movie_genres
ADD CONSTRAINT fk_movie
FOREIGN KEY (id_movie) REFERENCES movie_1(id); 

