USE movie_5;
SELECT * FROM movie_5.genres;
-- select * from genres order by genres;
-- ALTER TABLE genres ADD id_genres int NOT NULL AUTO_INCREMENT primary key;
-- ALTER TABLE genres CHANGE id_genres id_genres INT(20) NOT NULL FIRST;
-- ALTER TABLE genres DROP COLUMN id_genre;

Drop table if exists numbers;
CREATE TABLE numbers (
  n INT PRIMARY KEY);

INSERT INTO numbers VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);

CREATE VIEW asso_genre_view AS
SELECT
  movie_1.id as id_movie,
  SUBSTRING_INDEX(SUBSTRING_INDEX(movie_1.genres, '|', numbers.n), '|', -1) genres
FROM
  numbers INNER JOIN movie_1
  ON CHAR_LENGTH(movie_1.genres)
     -CHAR_LENGTH(REPLACE(movie_1.genres, '|', ''))>=numbers.n-1
ORDER BY
  id, n;
  
SELECT * FROM asso_genre_view;

CREATE TABLE asso_movie_genres AS
SELECT a.id_movie, g.id_genres
FROM asso_genre_view as a
LEFT JOIN genres as g
ON a.genres = g.genres;

SELECT * FROM asso_movie_genres;

DROP TABLE movie_genres;

-- CREATE TABLE IF NOT exists movie_genres AS
-- SELECT
--   movie_1.id as id_movie,
--   SUBSTRING_INDEX(SUBSTRING_INDEX(movie_1.genres, '|', numbers.n), '|', -1) genres
-- FROM
--   numbers INNER JOIN movie_1
--   ON CHAR_LENGTH(movie_1.genres)
--      -CHAR_LENGTH(REPLACE(movie_1.genres, '|', ''))>=numbers.n-1
-- ORDER BY
--   id, n;
  

  
