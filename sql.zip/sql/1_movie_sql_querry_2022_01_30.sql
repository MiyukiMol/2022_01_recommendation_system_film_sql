USE movie_5;
SELECT * FROM movie_5.movie;

-- ALTER TABLE movie ADD id int NOT NULL AUTO_INCREMENT primary key;
-- ALTER TABLE movie CHANGE id id INT(20) NOT NULL FIRST;
-- ALTER TABLE movie DROP COLUMN MyUnknownColumn;

DROP VIEW movie_1_view;
CREATE VIEW movie_1_view AS
SELECT m.id, m.movie_title, m.director_name, d.director_name as d_name, d.id_director,
	actor_1_name, a1.actor_name as actor1_name, a1.id_actor as id_actor_1,
    actor_2_name, a2.actor_name as actor2_name, a2.id_actor as id_actor_2,
    actor_3_name, a3.actor_name as actor3_name, a3.id_actor as id_actor_3,
    genres, plot_keywords, gross, budget, imdb_score, country, language, color, duration, title_year, movie_imdb_link, content_rating,
    num_critic_for_reviews, num_voted_users, facenumber_in_poster, num_user_for_reviews, aspect_ratio,
    director_facebook_likes, actor_1_facebook_likes, actor_2_facebook_likes, actor_3_facebook_likes, cast_total_facebook_likes, movie_facebook_likes
FROM movie as m
LEFT JOIN actor as a1
ON m.actor_1_name = a1.actor_name
LEFT JOIN actor as a2
ON m.actor_2_name = a2.actor_name
LEFT JOIN actor as a3
ON m.actor_3_name = a3.actor_name
LEFT JOIN director as d
ON m.director_name = d.director_name
ORDER BY m.id
;

SELECT * FROM movie_1_view;
-- create movie_1
DROP TABLE movie_1;
CREATE TABLE IF NOT EXISTS movie_1 AS
SELECT m.id, m.movie_title, d.id_director,
	a1.id_actor as id_actor_1,
    a2.id_actor as id_actor_2,
    a3.id_actor as id_actor_3,
    genres, plot_keywords, gross, budget, imdb_score, country, language, color, duration, title_year, movie_imdb_link, content_rating,
    num_critic_for_reviews, num_voted_users, facenumber_in_poster, num_user_for_reviews, aspect_ratio,
    director_facebook_likes, actor_1_facebook_likes, actor_2_facebook_likes, actor_3_facebook_likes, cast_total_facebook_likes, movie_facebook_likes
FROM movie as m
LEFT JOIN actor as a1
ON m.actor_1_name = a1.actor_name
LEFT JOIN actor as a2
ON m.actor_2_name = a2.actor_name
LEFT JOIN actor as a3
ON m.actor_3_name = a3.actor_name
LEFT JOIN director as d
ON m.director_name = d.director_name
ORDER BY m.id
;
ALTER TABLE movie_1 MODIFY id INT NOT NULL AUTO_INCREMENT PRIMARY KEY;
SELECT * FROM movie_1;

