USE movie_5;
SELECT * FROM movie_5.movie_1;

-- le top 10 des films les plus rentables
DROP VIEW IF EXISTS rentable_top10_view;

CREATE VIEW rentable_top10_view AS
SELECT id, movie_title, gross - budget as rentable
FROM movie_1
WHERE gross != -1 OR budget != -1
ORDER BY gross - budget DESC
LIMIT 10;

SELECT * FROM rentable_top10_view;


-- le top 10 des films les moins rentables
-- -1 :unknown
DROP VIEW IF EXISTS moins_rentable_top10_view;

CREATE VIEW moins_rentable_top10_view AS
SELECT id, movie_title, gross - budget as rentable
FROM movie_1
WHERE gross != -1 OR budget != -1
ORDER BY gross - budget
LIMIT 10;

SELECT * FROM moins_rentable_top10_view;
-------
select id, movie_title, gross, budget
from movie_1
where id = 2881 or id = 3740;
-------

-- les directeurs qui ont fait le plus de films : Steven Spielberg 26 films
SELECT count(*), d.d_first_name, d.d_last_name
FROM movie_1 as m
LEFT JOIN director as d
ON d.id_director = m.id_director
GROUP BY m.id_director
HAVING d.d_last_name != 'Unknown'
ORDER BY count(*) DESC
;


-- l'acteur qui a joué dans le plus de films
-- Robert De Niro 53 films
-- Morgan Freeman 43 films
-- Bruce Willis 38 films
SELECT * FROM top_1_actor_view;
DROP VIEW IF EXISTS actor_top10_view;

CREATE VIEW actor_top10_view as
SELECT count(*) as count1, id_actor_1 as actor
FROM movie_1
GROUP BY id_actor_1
UNION ALL
SELECT count(*) as count2, id_actor_2 as actor
FROM movie_1
GROUP BY id_actor_2
UNION ALL
SELECT count(*) as count2, id_actor_3 as actor
FROM movie_1
GROUP BY id_actor_3;
;
SELECT sum(count1) FROM actor_top10_view
group by actor
;
CREATE VIEW top_1_actor_view AS
select actor, actor_name, sum(count1) from actor_top10_view, actor
WHERE actor = id_actor AND actor_name != 'Unknown'
group by actor
order by sum(count1) DESC
;
SELECT * FROM top_1_actor_view;
-- le nombre de films avec "love" dans les mots clés : 229 films
SELECT count(id)
FROM movie_1
WHERE plot_keywords LIKE '% love %' OR plot_keywords LIKE '% love' OR
	plot_keywords LIKE '%|love %' OR 
    plot_keywords LIKE '% love|%' OR 
    plot_keywords LIKE '%|love|%' OR 
    plot_keywords LIKE 'love|%' OR plot_keywords LIKE '%|love'
;

-- le nombre de films français (langue) : 73 
-- le nombre de films français (country) : 154

select plot_keywords from movie_1;
SELECT count(*)
FROM movie_1
WHERE language = 'French'
;
SELECT count(*)
FROM movie_1
WHERE country = 'France';

-- le directeur avec au moins 10 films qui obtient la meilleure moyenne (note imdb)
-- David Fincher 7.75, 10 filmes
SELECT count(*), d.director_name, round(AVG(imdb_score),2) as moyenne_imdb_score
FROM movie_1 as m
LEFT JOIN director as d
ON d.id_director = m.id_director
WHERE imdb_score != -1
GROUP BY m.id_director
HAVING d.director_name != 'Unknown' AND count(*) >=10
ORDER BY AVG(imdb_score) DESC
LIMIT 1
;

-- David Fincher, id_director = 64
-- les filmes de David Fincher
select id, movie_title, id_director, imdb_score
from movie_1
where id_director = 64;

-- le directeur qui obtient la meilleure moyenne (note imdb)
SELECT count(*), d.director_name, round(AVG(imdb_score),2) as moyenne_imdb_score
FROM movie_1 AS m
LEFT JOIN director AS d
ON m.id_director = d.id_director
GROUP BY m.id_director
ORDER BY AVG(imdb_score) DESC
LIMIT 10
;