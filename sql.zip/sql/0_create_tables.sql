CREATE SCHEMA IF NOT EXISTS `movie_5` ;
DROP SCHEMA movie_5;

USE movie_5;
CREATE TABLE IF NOT EXISTS director (
id_director INT AUTO_INCREMENT NOT NULL,
director_name VARCHAR(255) NOT NULL,
d_first_name VARCHAR(255) NOT NULL,
d_last_name VARCHAR(255) NOT NULL,
PRIMARY KEY (id_director)
);

CREATE TABLE IF NOT EXISTS movie (
id INT AUTO_INCREMENT NOT NULL,
movie_title VARCHAR(255) NOT NULL,
director_name VARCHAR(255) NOT NULL,
actor_1_name VARCHAR(255) NOT NULL,
actor_2_name VARCHAR(255) NOT NULL,
actor_3_name VARCHAR(255) NOT NULL,
num_critic_for_reviews VARCHAR(255) NOT NULL,
duration FLOAT NOT NULL,
director_facebook_likes FLOAT NOT NULL,
actor_1_facebook_likes FLOAT NOT NULL,
actor_2_facebook_likes FLOAT NOT NULL,
actor_3_facebook_likes FLOAT NOT NULL,
color VARCHAR(255) NOT NULL,
gross FLOAT NOT NULL,
genres VARCHAR(255) NOT NULL,
num_voted_users INT NOT NULL,
cast_total_facebook_likes INT NOT NULL, 
facenumber_in_poster INT NOT NULL, 
plot_keywords VARCHAR(255) NOT NULL,
movie_imdb_link VARCHAR(255) NOT NULL,
num_user_for_reviews FLOAT NOT NULL,
language VARCHAR(255) NOT NULL,
country VARCHAR(255) NOT NULL,
content_rating VARCHAR(255) NOT NULL,
budget FLOAT NOT NULL,
title_year INT NOT NULL,
imdb_score FLOAT NOT NULL,
aspect_ratio FLOAT NOT NULL,
movie_facebook_likes INT NOT NULL,
PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS genres (
id_genres INT AUTO_INCREMENT NOT NULL,
genres VARCHAR(255) NOT NULL,
PRIMARY KEY (id_genres)
);

-- CREATE TABLE IF NOT EXISTS actor (
-- id_actor INT AUTO_INCREMENT NOT NULL,
-- actor_name VARCHAR(255) NOT NULL,
-- PRIMARY KEY (id_actor)
-- );

CREATE TABLE IF NOT EXISTS actor (
id_actor INT AUTO_INCREMENT NOT NULL,
actor_name VARCHAR(255) NOT NULL,
a_first_name VARCHAR(255) NOT NULL,
a_last_name VARCHAR(255) NOT NULL,
PRIMARY KEY (id_actor)
);

