SELECT * FROM movie_5.asso_movie_genres;

use movie_5;

CREATE VIEW movie_genres_view AS
select m.id, m.movie_title, g.genres
from movie_1 as m
left join asso_movie_genres as amg
on m.id = amg.id_movie
left join genres as g
on amg.id_genres = g.id_genres;

SELECT *
FROM movie_genres_view;