SELECT * FROM movie_4.director;
-- create id_director
-- ALTER TABLE director ADD id_director int NOT NULL AUTO_INCREMENT primary key;
-- ALTER TABLE director CHANGE id_director id_director INT(20) NOT NULL FIRST;
-- ALTER TABLE director DROP COLUMN MyUnknownColumn;

ALTER TABLE movie_1
ADD CONSTRAINT fk_director
FOREIGN KEY (id_director) REFERENCES director(id_director); 

-- ALTER TABLE director DROP COLUMN director_name;
